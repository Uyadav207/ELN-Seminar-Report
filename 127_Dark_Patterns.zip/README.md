seminar-template
================

HTML/CSS Template of Web Engineering Seminar

# How to contribute

You have found a bug or want to improve the template of the seminar?
Do not hesitate to make a pull request with your improvements. To ease the way of collaboration please provide a screenshot that illustrates the changes you have made.
